package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.santosh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CommitteeListAdapter extends BaseAdapter {
    private Context context;
    private JSONArray committeearr;
    private LayoutInflater mInflater;

    public CommitteeListAdapter(Context context, JSONArray billResArray) {
        this.context = context;
        this.committeearr = billResArray;
        this.mInflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return committeearr.length();
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = mInflater.inflate(R.layout.listcom, null);
        JSONObject committeeListItem = null;
        try {
            committeeListItem = committeearr.getJSONObject(position);
            TextView committeeId = (TextView) convertView.findViewById(R.id.committee_id);
            committeeId.setText(committeeListItem.getString("committee_id"));
            TextView committeeName = (TextView) convertView.findViewById(R.id.committee_name);
            committeeName.setText(committeeListItem.getString("name"));
            TextView committeeChamber = (TextView) convertView.findViewById(R.id.committee_chamber);
            String name = committeeListItem.getString("chamber");
            name = name.substring(0,1).toUpperCase() + name.substring(1).toLowerCase();
            committeeChamber.setText(name);


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }
}
