package adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.santosh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BillListAdapter extends BaseAdapter {
    private Context context;
    private JSONArray billsarr;
    private LayoutInflater mInflater;

    public BillListAdapter(Context context, JSONArray billsarr) {
        this.context = context;
        this.billsarr = billsarr;
        this.mInflater = LayoutInflater.from(this.context);
    }

    public void clearData() {
        billsarr = new JSONArray();
    }

    @Override
    public int getCount() {
        return billsarr.length();
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = mInflater.inflate(R.layout.listbill, null);
        JSONObject billListItem = null;
        try {
            billListItem = billsarr.getJSONObject(position);
            TextView billId = (TextView) convertView.findViewById(R.id.bill_id);
            billId.setText(billListItem.getString("bill_id"));
            TextView billTitle = (TextView) convertView.findViewById(R.id.bill_title);
            billTitle.setText(billListItem.getString("short_title").equals("null") ?
                                billListItem.getString("official_title") : billListItem.getString("short_title"));
            TextView billIntroduced = (TextView) convertView.findViewById(R.id.introduced_on);
            Date date_s = null;
            try {
                date_s = new SimpleDateFormat("yyyy-MM-dd").parse(billListItem.getString("introduced_on"));
            }catch (java.text.ParseException e){
            }
            billIntroduced.setText(new SimpleDateFormat("MMM dd, yyyy").format(date_s));


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }

}
