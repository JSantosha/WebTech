package adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.santosh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LegislatorListAdapter extends BaseAdapter {

    private Context context;
    private JSONArray legislatorResArray;
    private LayoutInflater mInflater;

    public LegislatorListAdapter(Context context, JSONArray legislatorResArray) {
        this.context = context;
        this.legislatorResArray = legislatorResArray;
        this.mInflater = LayoutInflater.from(this.context);
    }

    @Override
    public int getCount() {
        return legislatorResArray.length();
    }

    @Override
    public Object getItem(int arg0) {
        return null;
    }

    @Override
    public long getItemId(int arg0) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = mInflater.inflate(R.layout.listlegis, null);
        JSONObject legislatorListItem = null;
        try {
            legislatorListItem = legislatorResArray.getJSONObject(position);

            String imgURL = "http://theunitedstates.io/images/congress/original/" + legislatorListItem.getString("bioguide_id") + ".jpg";
            Log.d("imgURL:   ", imgURL);
            ImageView imageView = (ImageView) convertView.findViewById(R.id.legislator_image);
            Glide.with(context).load(imgURL).diskCacheStrategy(DiskCacheStrategy.ALL).into(imageView);

            TextView name = (TextView) convertView.findViewById(R.id.legislator_name);
            name.setText(legislatorListItem.getString("last_name") + ", " + legislatorListItem.getString("first_name"));

            TextView party = (TextView) convertView.findViewById(R.id.legislator_party);
            party.setText("(" + legislatorListItem.getString("party") + ")");

            TextView state = (TextView) convertView.findViewById(R.id.legislator_state);
            state.setText(legislatorListItem.getString("state_name") + (legislatorListItem.getString("district").equals("null") ? " " : " - "));

            TextView district = (TextView) convertView.findViewById(R.id.legislator_district);
            district.setText((legislatorListItem.getString("district").equals("null") ? " " : "District " + legislatorListItem.getString("district")));

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return convertView;
    }

}
