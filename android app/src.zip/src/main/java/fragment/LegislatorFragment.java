package fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TextView;
import android.widget.Toast;

import com.example.santosh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import activity.LegislatorDetailActivity;
import adapter.LegislatorListAdapter;
import fragment.BillChildFragment.Active_Tab;
import fragment.BillChildFragment.Passive_Tab;
import loadjson.LegislatorLoad;
import other.JsonSort;

public class LegislatorFragment extends Fragment implements LegislatorLoad.Listener, AdapterView.OnItemClickListener, View.OnClickListener {
    private FragmentTabHost mTabHost;
    private final String byStatesTabTag = "byStatesTabTag";
    private final String houseTabTag = "hosueTabTag";
    private final String senateTabTag = "senateTabTag";
    private ListView mListView = null;
    private Map<String, Integer> mapIndex = null;
    private JSONArray legislators = null;

    private OnFragmentInteractionListener mListener;

    public LegislatorFragment() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onLoaded(String legislatorResponse) {
//        JSONObject legislatorResult;
        JSONArray legislatorResArray = null;
        try {
            legislatorResArray = new JSONObject(legislatorResponse).getJSONArray("results");
//            legislators = new JSONObject(legislatorResponse).getJSONArray("results");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        String currentTab = mTabHost.getCurrentTabTag();
        if(currentTab.equals(byStatesTabTag)) {
            legislatorResArray = JsonSort.sort(legislatorResArray, new Comparator() {
                @Override
                public int compare(Object o1, Object o2) {
                    JSONObject ja = (JSONObject) o1;
                    JSONObject jb = (JSONObject) o2;
                    int ans = 0;
                    try {
                        ans = ja.getString("state_name").toLowerCase().compareTo(jb.getString("state_name").toLowerCase());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return ans;
                }
            });
        }
        else {
            legislatorResArray = JsonSort.sort(legislatorResArray, new Comparator() {
                @Override
                public int compare(Object o1, Object o2) {
                    JSONObject ja = (JSONObject) o1;
                    JSONObject jb = (JSONObject) o2;
                    int ans = 0;
                    try {
                        ans = ja.getString("last_name").toLowerCase().compareTo(jb.getString("last_name").toLowerCase());
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    return ans;
                }
            });
        }

        legislators = legislatorResArray;

        loadListView(legislatorResArray);
        getIndexList(legislatorResArray);
        displayIndex();

    }

    private void getIndexList(JSONArray legislatorResArray) {
        String currentTab = mTabHost.getCurrentTabTag();
        mapIndex = new LinkedHashMap<>();
        try {
            for(int i = 0; i < legislatorResArray.length(); i++) {
                JSONObject legislatorListItem = legislatorResArray.getJSONObject(i);
                String indexKeyString = currentTab.equals(byStatesTabTag) ?
                        legislatorListItem.getString("state_name") : legislatorListItem.getString("last_name");
                String index = indexKeyString.substring(0, 1);
                if(mapIndex.get(index) == null) {
                    mapIndex.put(index, i);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

    }

    private void displayIndex() {
        LinearLayout indexLayout = (LinearLayout) getView().findViewById(R.id.slide_index);
        indexLayout.removeAllViews();
        Context context = getActivity();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        TextView textView = null;
        List<String> indexList = new ArrayList<>(mapIndex.keySet());
        for(String index : indexList) {
            textView = (TextView) inflater.inflate(R.layout.slide_index_item, null);
            textView.setText(index);
            textView.setOnClickListener(LegislatorFragment.this);
            indexLayout.addView(textView);
        }
    }

    @Override
    public void onClick(View view) {
        TextView selectedIndex = (TextView) view;
        mListView.setSelection(mapIndex.get(selectedIndex.getText()));
    }


    private void loadListView(JSONArray legislatorResArray) {
        LegislatorListAdapter adapter = new LegislatorListAdapter(getActivity(), legislatorResArray);
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                JSONObject legislator = null;
                try {
                    legislator = legislators.getJSONObject(position);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Intent intent = new Intent(getActivity(), LegislatorDetailActivity.class);
                intent.putExtra("legislator", legislator.toString());
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onError() {
        Toast.makeText(getActivity(), "Error !", Toast.LENGTH_SHORT).show();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View rootView =  inflater.inflate(R.layout.fragment_legislator, container, false);
        mListView = (ListView) rootView.findViewById(R.id.listview_legislator);
        new LegislatorLoad(LegislatorFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=state");

        mTabHost = (FragmentTabHost) rootView.findViewById(android.R.id.tabhost);
        mTabHost.setup(getActivity(), getChildFragmentManager(), R.id.realtabcontent);
        mTabHost.addTab(mTabHost.newTabSpec(byStatesTabTag).setIndicator("by states"), Active_Tab.class, null);
        mTabHost.addTab(mTabHost.newTabSpec(houseTabTag).setIndicator("house"), Passive_Tab.class, null);
        mTabHost.addTab(mTabHost.newTabSpec(senateTabTag).setIndicator("senate"), Passive_Tab.class, null);

        mTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if(byStatesTabTag.equals(tabId)) {
                    new LegislatorLoad(LegislatorFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=state");
                }
                else if(houseTabTag.equals(tabId)) {
                    new LegislatorLoad(LegislatorFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=house");
                }
                else if(senateTabTag.equals(tabId)) {
                    new LegislatorLoad(LegislatorFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=senate");
                }
            }
        });
        return rootView;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
