package fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.Toast;

import com.example.santosh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import activity.BillDetailActivity;
import adapter.BillListAdapter;
import fragment.BillChildFragment.Active_Tab;
import fragment.BillChildFragment.Passive_Tab;
import loadjson.BillLoad;
import other.JsonSort;


public class BillFragment extends Fragment implements BillLoad.Listener, AdapterView.OnItemClickListener {

    private FragmentTabHost mTabHost;
    private final String activeTabTag = "activeTabTag";
    private final String newTabTag = "newTabTag";
    private List<HashMap<String, String>> mBillMapList = null;
    private ListView mListView = null;
    private JSONArray bills = null;


    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public BillFragment() {
        // Required empty public constructor
    }


    public static BillFragment newInstance(String param1, String param2) {
        BillFragment fragment = new BillFragment();
        Bundle args = new Bundle();
        args.putString("param1", param1);
        args.putString("param2", param2);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString("param1");
            mParam2 = getArguments().getString("param2");
        }
    }

    @Override
    public void onLoaded(String billResponse) {
//        JSONObject billResult;
        JSONArray billResArray = null;
        try {
             billResArray = new JSONObject(billResponse).getJSONArray("results");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        billResArray = JsonSort.sort(billResArray, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                JSONObject ja = (JSONObject) o1;
                JSONObject jb = (JSONObject) o2;
                int ans = 0;
                try {
                    ans = jb.getString("introduced_on").toLowerCase().compareTo(ja.getString("introduced_on").toLowerCase());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                return ans;
            }
        });

        bills = billResArray;
        loadListView(billResArray);
    }

    @Override
    public void onError() {
        Toast.makeText(getActivity(), "Error !", Toast.LENGTH_SHORT).show();
    }

    private void loadListView(JSONArray billResArray) {
        BillListAdapter adapter = new BillListAdapter(getActivity(), billResArray);
        mListView.setAdapter(adapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                JSONObject bill = null;
                try {
                    bill = bills.getJSONObject(position);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                Intent intent = new Intent(getActivity(), BillDetailActivity.class);
                intent.putExtra("bill", bill.toString());
                startActivity(intent);
            }
        });
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        final View rootView =  inflater.inflate(R.layout.fragment_bill, container, false);
        mListView = (ListView) rootView.findViewById(R.id.listview_bill);
        new BillLoad(BillFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=active");

        mTabHost = (FragmentTabHost) rootView.findViewById(android.R.id.tabhost);
        mTabHost.setup(getActivity(), getChildFragmentManager(), R.id.realtabcontent);
        mTabHost.addTab(mTabHost.newTabSpec(activeTabTag).setIndicator("active bill"), Active_Tab.class, null);
        mTabHost.addTab(mTabHost.newTabSpec(newTabTag).setIndicator("new bill"), Passive_Tab.class, null);

        mTabHost.setOnTabChangedListener(new TabHost.OnTabChangeListener() {
            @Override
            public void onTabChanged(String tabId) {
                if(activeTabTag.equals(tabId)) {
                    new BillLoad(BillFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=active");
                }
                else {
                    new BillLoad(BillFragment.this).execute("http://santoshaapp-env.us-west-2.elasticbeanstalk.com?st=new");
                }
            }
        });
        return rootView;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString());
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
