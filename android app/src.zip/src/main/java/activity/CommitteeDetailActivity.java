package activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.santosh.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class CommitteeDetailActivity extends AppCompatActivity {

    private String jsonStr = "";
    private JSONObject committeeObj;
    private JSONArray favoriteCommittees;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_committee_detail);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        try {
            // current legislator
            jsonStr = getIntent().getStringExtra("committee");
            committeeObj = new JSONObject(jsonStr);
            // shared preference
            final SharedPreferences sharedPreferences = getSharedPreferences("favorites", Context.MODE_PRIVATE);
            final SharedPreferences.Editor editor = sharedPreferences.edit();
            final String strForStar = sharedPreferences.getString("favorite_committees", "");
            boolean starEmpty = false;
            if(strForStar.length() == 0 || strForStar.equals("{\"results\":[]}") ||
                    !strForStar.toLowerCase().contains(committeeObj.getString("committee_id").toLowerCase())) {
                starEmpty = true;
            }

            // favorite star
            final ImageView starIcon = (ImageView) findViewById(R.id.detail_committee_star);
            starIcon.setImageResource(starEmpty == false ? R.drawable.star_filled : R.drawable.star);
            starIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // current bill id
                    String committeeId = "";
                    try {
                        committeeId = committeeObj.getString("committee_id");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    // judge whether bill Id exists
                    final String preferenceStr = sharedPreferences.getString("favorite_committees", "");
                    try {
                        if(preferenceStr.length() == 0) {
                            favoriteCommittees = new JSONArray();
                        }
                        else {
                            favoriteCommittees = new JSONObject(preferenceStr).getJSONArray("results");
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }


                    if(!preferenceStr.toLowerCase().contains(committeeId.toLowerCase())) {
                        favoriteCommittees.put(committeeObj);
                        starIcon.setImageResource(R.drawable.star_filled);
                    }
                    else {
                        // delete it
//                        int step = 0;
                        JSONArray res = new JSONArray();
                        for(int i = 0; i < favoriteCommittees.length(); i++) {
                            try {
                                if(!favoriteCommittees.getJSONObject(i).getString("committee_id").equals(committeeId)) {
                                    res.put(favoriteCommittees.get(i));
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        favoriteCommittees = res;
                        starIcon.setImageResource(R.drawable.star);
                    }
                    editor.putString("favorite_committees", "{\"results\":" + favoriteCommittees.toString() + "}");
                    editor.commit();
                }
            });

            // committee id
            TextView committeeId = (TextView) findViewById(R.id.detail_committee_id);
            committeeId.setText(committeeObj.getString("committee_id"));

            // name
            TextView name = (TextView) findViewById(R.id.detail_committee_name);
            name.setText(committeeObj.getString("name"));

            // chamber
            final ImageView chamberImg = (ImageView) findViewById(R.id.detail_committee_chamber_image);
            String chamberStr = committeeObj.getString("chamber");
            if(chamberStr.equals("house")) {
                Glide.with(this).load("http://cs-server.usc.edu:45678/hw/hw8/images/h.png")
                        .crossFade()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(chamberImg);
            }
            else {
                Glide.with(this).load("http://www-scf.usc.edu/~jillella/HW8/s.png")
                        .crossFade()
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(chamberImg);
            }
            TextView chamber = (TextView) findViewById(R.id.detail_committee_chamber);
            String name_cham = committeeObj.getString("chamber");
            name_cham = name_cham.substring(0,1).toUpperCase() + name_cham.substring(1).toLowerCase();
            chamber.setText(name_cham);


            // parent committee
            TextView parent = (TextView) findViewById(R.id.detail_committee_parent_committee);
            parent.setText(committeeObj.has("parent_committee_id") == false ?
                            "N.A." : committeeObj.getString("parent_committee_id"));

            // contact
            TextView contact = (TextView) findViewById(R.id.detail_committee_contact);
            contact.setText(committeeObj.has("phone") == false ?
                            "N.A." : committeeObj.getString("phone"));

            // office
            TextView office = (TextView) findViewById(R.id.detail_committee_office);
            office.setText(committeeObj.has("office") == false ?
                            "N.A." : committeeObj.getString("office"));

        } catch (JSONException e) {
            e.printStackTrace();
        }
        
        getSupportActionBar().setTitle("Committee Info");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == android.R.id.home) {
            onBackPressed();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
