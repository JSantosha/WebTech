Congress API(HW9):
Gives the information of the various congress members in the legislators, related bills and committees.
The favorites gives the list of all the information tha the user bookmarks
The about me tell about the author